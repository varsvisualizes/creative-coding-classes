// Here is a simple way to create snowflakes from fractals!

function setup() {
  createCanvas(400, 400);
  rectMode(CENTER);

}

function draw() {
  background(220);
  noFill();
  
  translate(width / 2, height / 2);
  snowflake(0, 0, 100);

}

function snowflake(x, y, length) {
  
  let halfLength = length / 2;

  rect(x, y, length, length);
  
  
  // upper left corner
  rect(x - halfLength, y - halfLength, halfLength, halfLength);

  // upper right corner
  rect(x + halfLength, y - halfLength, halfLength, halfLength);

  // lower left corner
  rect(x - halfLength, y + halfLength, halfLength, halfLength);

  // lower right corner
  rect(x + halfLength, y + halfLength, halfLength, halfLength);

  length -= 10;

  if (length >= 10) {
    
    // upper left corner
    snowflake(x-halfLength, y-halfLength, length/3);
           
    // upper right corner
    snowflake(x+halfLength, y-halfLength, halfLength);
    
    // lower left corner
    snowflake(x-halfLength, y+halfLength, halfLength);
    
    // lower right corner
    snowflake(x+halfLength, y+halfLength, length/3);
  }
}
