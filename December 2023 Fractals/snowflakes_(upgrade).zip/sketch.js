// Here is a more complex way to make snowflakes from 
// fractals!
// This changes the shape and position of the fractal 
// based on the mouse's position on the canvas.

let angle = 0;
let mousePos;

function setup() {
  createCanvas(400, 400);
  rectMode(LEFT);
  angleMode(DEGREES);
}

function draw() {
  background(220);
  noFill();
  
  mousePos = map(mouseX, 0, width, 0, 250);
  
  push();
  translate(mouseX, mouseY);
  rotate(angle);
  snowflake(mousePos, mousePos, mousePos);
  pop();
  
  angle+= 2;
}

function snowflake(x, y, length) {
  
  let halfLength = length / 2;

  rect(x, y, length, length);
  
  
  // upper left corner
  rect(x - halfLength, y - halfLength, halfLength, halfLength);

  // upper right corner
  rect(x + halfLength, y - halfLength, halfLength, halfLength);

  // lower left corner
  rect(x - halfLength, y + halfLength, halfLength, halfLength);

  // lower right corner
  rect(x + halfLength, y + halfLength, halfLength, halfLength);

  length -= 10;

  if (length >= 10) {
    // upper left corner
    snowflake(x-halfLength, y-halfLength, length/3);
           
    // upper right corner
    snowflake(x+halfLength, y-halfLength, halfLength);
    
    // lower left corner
    snowflake(x-halfLength, y+halfLength, halfLength);
    
    // lower right corner
    snowflake(x+halfLength, y+halfLength, length/3);
  }
}
