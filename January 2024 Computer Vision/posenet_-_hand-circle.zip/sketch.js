
// First, we set up our variables. This way we can easily reference them later, and the computer knows what we're talking about.

// We're going to have a video playing using our webcam.
let video;

// We're going to tell the Machine Learning library to let us access all its information on "PoseNet", which is what the computer will use to detect where our body parts are.
let poseNet;

// We're going to refer to all the differnt possible poses as "pose."
let pose;

// let's set up our video
function setup() {
  
  // Set up the canvas to play the video on
  createCanvas(640, 480);
  
  // Tell the computer that the video variable means a the webcam video
  video = createCapture(VIDEO);
  
  // Oops, it wants to play another video below the canvas! Let's hide this video, so we can put it on the canvas later on.
  video.hide();
  
  // Now we load up all the information about PoseNet from the Machine Learning library.
  poseNet = ml5.poseNet(video, modelLoaded);
  
  // If you detect a person, checking for the "keypoints" at their body parts!
  poseNet.on('pose', gotPoses);
 
}


// Let's put all the poses from PoseNet into a list called an array, so we can easily call on them.
function gotPoses(poses) {
  
  // This will list out all the poses we can get. 
  console.log(poses);
  
  // Get the names of all of the keypoints we can access. 
  // 
  //You can see the list here, under "Keypoint Diagram: COCO KeyPoints" - https://github.com/tensorflow/tfjs-models/tree/master/pose-detection
  if(poses.length > 0) {
    pose = poses[0].pose;
  }
}

// Let us know when the poses are loaded up and we're ready to roll
function modelLoaded() {
  console.log("Ready to start posing!");
}

// Now we can start drawing based on the poses the computer can see!
// This is where you have the most freedom: Customize as much as you want, experiment, and see what happens.
function draw() {
  
  // First, let's tell the webcam video to play in the canvas we set up.
  // image(video, 0, 0);
  background(0);
  
  // Last double-check: Can the camera see a person posing? If it can, let's go!
  if(pose) {
    
    // Find our left and right wrists.
    let wristL = pose.leftWrist;
    let wristR = pose.rightWrist;
    
    // Now, compute how far away our wrists are from each other.
    let d = dist(wristL.x, wristL.y, wristR.x, wristR.y);
    
    // Awesome. Now let's tell it where our nose is so we can use it as a center point.
    let nose = pose.nose;
    
    // With that, let's make a circle that goes from one wrist to the other!
    
    // I want the circle to be empty in the middle, so I tell it "No Fill."
    noFill();
    
    // I want the line color to be pink, and I want to make it a little heavy. I use RGB to tell it what color I want - here's a handy RGB table link: https://www.rapidtables.com/web/color/RGB_Color.html
    stroke(255, 102, 200);
    strokeWeight(4);
    
    // Finally: With the center of the circle at my nose, make the circle as wide as the space between my hands/wrists.
    ellipse(nose.x, nose.y, d);
    
    
  }
  
}