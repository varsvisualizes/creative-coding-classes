let gifLoad, gifPlay, video, poseNet, pose;

function preload() {
  gifLoad = loadImage("heartgif.gif");
  // gifPlay = createImg("heartgif.gif");
}

function setup() {
  createCanvas(500, 420);
  
  video = createCapture(VIDEO);
  video.hide();
  
  poseNet = ml5.poseNet(video, modelLoaded);
  poseNet.on('pose', gotPoses)
  
  gifLoad.resize(700, 700);
  
  background(0);
}

function gotPoses(poses) {
  // console.log(poses);
    if (poses.length > 0) {
      pose = poses[0].pose;
    }
}

function modelLoaded() {
  console.log('poseNet Ready');
}

function draw() {

  // gifPlay.position(50, 50);
  
  image(video, 0, 0);
  
  if(pose) {
    
    // gifPlay.resize(400, 320);
    // gifPlay.position(pose.nose.x-250, pose.nose.y-250);
    
    let eyeR = pose.rightEye;
    let eyeL = pose.leftEye;
    let d = dist(eyeR.x, eyeR.y, eyeL.x, eyeL.y);
    
    console.log(d);
    
    // how might i want to use the distance function? tbd
    
    push();
    imageMode(CENTER);
    image(gifLoad, pose.nose.x, pose.nose.y, (gifLoad.width * d)/75, (gifLoad.height * d)/75);
    pop();
    
  }
  
  
  
}
