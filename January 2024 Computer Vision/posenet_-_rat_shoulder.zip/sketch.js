let video, poseNet, pose;
let ratPic, ratSW, ratSH, ratW, ratH;

function preload() {
  ratPic = loadImage("rat.png");
}

function setup() {
  createCanvas(500, 420);

  video = createCapture(VIDEO);
  video.hide();

  poseNet = ml5.poseNet(video, modelLoaded);
  poseNet.on("pose", gotPoses);
  
  ratSW = ratPic.width;
  ratSH = ratPic.height;

  background(0);
}

function gotPoses(poses) {
  // console.log(poses);
  if (poses.length > 0) {
    pose = poses[0].pose;
  }
}

function modelLoaded() {
  console.log("poseNet Ready");
}

function draw() {
  imageMode(CORNER);
  image(video, 0, 0);
  
  // ratPic.resize(ratSW, ratSH)

  if (pose) {

    let eyeR = pose.rightEye;
    let eyeL = pose.leftEye;
    let d = dist(eyeR.x, eyeR.y, eyeL.x, eyeL.y);

    console.log("D is " + d);

    ratW = map(d, 0, ratPic.width, 50, (ratPic.width * d) / 50);
    ratH = map(d, 0, ratPic.height, 50, (ratPic.height * d) / 50);

    console.log("RatW was " + ratPic.width + " and will now be " + ratW);
    console.log("RatH was " + ratPic.height + " and will now be " + ratH);

    if (ratW > 0 && ratH > 0) {
      // ratPic.resize(ratW, ratH);
      
      imageMode(CENTER);
      image(ratPic, pose.rightShoulder.x, pose.rightShoulder.y-d, ratW, ratH);
    }

    
  }
}
