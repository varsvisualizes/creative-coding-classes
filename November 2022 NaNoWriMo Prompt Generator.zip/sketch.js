// declare 3 sentence banks to be filled in
let sentence1 = [];
var sentence1Max;
let sentence2 = [];
var sentence2Max;
let sentence3 = [];
var sentence3Max;

// a counter to reset our story 
var count = 0;

// determine how high on the page the text will show up
//
var textHeight = 200;

// have this amount of spacing between each sentence
var leading = 30; 

// make our text size this value
var wordSize = 50;

// the function to set up the sketch
function setup() {
	createCanvas(windowWidth, windowHeight);
	background(255);
	
	// sentence bank 1 - ***customize as you wish!*** 
	// rewrite lines, add lines, remove lines, just follow the syntax pattern
	// "whatever you want in quotation marks"(comma unless it's the last item in the list)
	sentence1 = [
		"there was a barber and his wife",
		"there was a poor boy and a hungry young girl",
		"there was a bastard, orphan, son of a--",
		"there were 38 planes",
		"there was a superboy and an invisible girl"
	];
	
	sentence1Max = sentence1.length-1;
	
	// sentence bank 2 - ***customize as you wish!***
	sentence2 = [
		"and she was beautiful", 
		"the boy was working on a song",
		"writing like they're running out of time",
		"for over an entire day",
		"he's a hero, a lover, a prince; she's not there"
	];
	
	sentence2Max = sentence2.length-1;
	
	// sentence bank 3 - ***customize as you wish!***
	sentence3 = [
		"oh, that was many years ago",
		"the girl was looking for food and firewood",
		"the man is nonstop",
		"and there was nothing but darkness and trees",
		"so catch her, she's falling"
	];
	
	sentence3Max = sentence3.length-1;
	
	// make all the text this font size 
	textSize(wordSize);
	
	textFont('Georgia');
	
	// our starting sentence, and where it's placed on the page 
	text("Once upon a time", 100, textHeight);
}

// this function runs every time you click the mouse
function mouseClicked(){
	
	// when the counter is 0, run this code
	if(count == 0) {
		
		// increment the counter by 1, to move on to the next sentence bank 
		count++;
		
		// have the program randomly choose a number between 0 and the number of sentences
		// in sentence bank
		var choice1 = round(random(0, sentence1Max));

		// print out the randomly selected sentence
		text((sentence1[choice1]),100,(textHeight + ((wordSize+leading)*count)));
		
	}
	
	// same as above, for the sentence2 array 
	else if(count == 1) {
		count++;
		var choice2 = round(random(0, sentence2Max));
		text((sentence2[choice2]),100,(textHeight + ((wordSize+leading)*count)));
	}
	
	// same as above, for the sentence3 array 
	else if(count == 2) {
		count++;
		var choice3 = round(random(0, sentence3Max));
		text((sentence3[choice3]),100,(textHeight + ((wordSize+leading)*count)));
	}
	
	// once we've run through the sentence banks, reset the sketch and the counter 
	// now we can play again! :)
	else {
		clear();
		background(255);
		text("Once upon a time", 100, textHeight);
		count = 0;
	}
}
