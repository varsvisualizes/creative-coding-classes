let xPos = 0;
let flag = 1;
let speed = 1;

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(18, 14, 235);
  
  noStroke();
  rect(xPos, 0, 10, 600);
  
  if(flag == 1) {
    xPos+=speed;
  }
  else if(flag == 0) {
    xPos-=speed;
  }
  
  if(xPos > width) {
    flag = 0;
  }
  
  if(xPos == 0) {
    flag = 1;
  }
  
}