var len = 400;
var wid = 400;
var colorArr = [];
var barSize = 10;
var arrLength = wid / barSize;

function setup() {
  createCanvas(len, 800);
  colorMode(HSL);
  colorPalette();
}

function colorPalette() {
  stroke(100);
  for (var i = 0; i < wid; i += barSize) {
    let c = color(random(0, 255), 70, 70);
    fill(c);
    rect(i, 0, barSize, len);
  }
}

function mouseClicked() {
  colorPalette();
}
