var len = 800;
var wid = 800;
var colorArr = [];
var barSize = 5;
var arrLength = wid / barSize;

function setup() {
  createCanvas(wid, len);
  colorPalette();
}

function colorPalette() {
  for (var i = 0; i < wid; i += barSize) {
    let c = color(random(0, 255));
    stroke(c);
    // rect(i, 0, barSize, len);
    bezier(250+i, 500+i, 250, 
           100-i, 100, -250, 
           wid, len/2, 0, 
           100-i, 100-i, 100-i)
  }
}

function mouseClicked() {
  colorPalette();
}
