/* 

a sketch of this painting: https://product-image.juniqe-production.juniqe.com/media/catalog/product/seo-cache/x800/802/93/802-93-101P/Hilma-af-Klint--The-Swan-No-17-Vintage-by-JUNIQE-Poster.jpg

*/

let angle = 0;
let speed;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  
  if (mouseIsPressed === true) {
    speed = 0.1;
  }
  else {
    speed = 0;
  }
  
  background(230, 84, 0);
  
  noStroke();
  
  push();
  
  translate(width/2, height/2);
  
  rotate(angle+=speed);
  
  fill(75, 127, 250);
  circle(0, 0, 200);
  
  fill(255,255,255);
  arc(0, 0, 200, 200, HALF_PI, (3*PI)/2);
  
  fill(0,0,0);
  circle(0,0,125);
  
  fill(237, 199, 95);
  arc(0,0,125,125,(3*PI)/2, HALF_PI)
  
  fill(250, 131, 125);
  arc(0, 0, 50, 50, (3*PI)/2, HALF_PI);
  
  pop();
  
}


