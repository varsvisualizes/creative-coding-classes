/* 

a sketch of this painting: https://product-image.juniqe-production.juniqe.com/media/catalog/product/seo-cache/x800/802/93/802-93-101P/Hilma-af-Klint--The-Swan-No-17-Vintage-by-JUNIQE-Poster.jpg

*/

function setup() {
  createCanvas(400, 400);
}

function draw() {
  
  background(230, 84, 0);
  
  noStroke();
  
  translate(width/2, height/2);
  
  fill(255, 255, 255);
  circle((0.08*(mouseX-220)), 0, 200);

  fill(75,127,250);
  arc((0.02*(mouseX-220)), 0, 200, 200, (3*PI)/2, HALF_PI);

  fill(0,0,0);
  circle((0.03*(mouseX-220)),0,125);

  fill(237, 199, 95);
  arc(-(0.03*(mouseX-220)),0,125,125,(3*PI)/2, HALF_PI)

  fill(250, 131, 125);
  arc(-(0.1*(mouseX-220)), 0, 50, 50, (3*PI)/2, HALF_PI);
  
}


