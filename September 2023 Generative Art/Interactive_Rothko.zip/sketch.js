function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(146, 169, 252);
  noStroke();
  
  fill(50, 35, 184);
  rect(20,20,360,120, 10, 5);
  
  fill(43, 86, 255);
  rect(20,150,360,60,5,10);
  
  fill(61, 48, 184, 100);
  rect(20,220,360,80);
  
  filter(BLUR,1.5);
  
  if(mouseX > 200) {
    filter(INVERT);
  }
  
}